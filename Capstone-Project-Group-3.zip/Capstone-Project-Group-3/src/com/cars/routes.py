from flask import Blueprint, render_template
from .controllerCars import CarsController

cars = Blueprint('cars', __name__, template_folder = 'templates', static_folder = 'static')


@cars.route('/cars')
def get_cars():
    get_all = CarsController().get_all()
    return render_template('cars.html', cars=get_all)


@cars.route('/single-car')
def get_singleCars():
    return render_template('single-car.html')