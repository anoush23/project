(function($) {

    console.log( "cars js" );

})(jQuery)