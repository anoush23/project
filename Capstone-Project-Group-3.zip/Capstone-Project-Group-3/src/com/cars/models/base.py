from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
# from .config import db_conf


Base = declarative_base()

# # engine = create_engine(db_conf['path'])
engine = create_engine('sqlite:///data.db', echo=True)
metadata = Base.metadata
metadata.create_all(engine)
Session = sessionmaker(bind=engine)
DB = Session()