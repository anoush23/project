from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from .base import Base, DB
from .cars import Cars


class Model(Base):
    __tablename__ = 'model'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, unique=True)
    model_car = relationship(Cars, back_populates="car_model")

    @staticmethod
    def get_all():
        try:
            return DB.query(Model).order_by(Model.id.desc()).all()
        except:
            DB.rollback()

    @staticmethod
    def get_by_id(id: int):
        try:
            return DB.query(Model).filter(Model.id == id).first()
        except:
            DB.rollback()

    @staticmethod
    def remove():
        pass

    def __repr__(self):
        return str(self.__dict__)


