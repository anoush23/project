from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from .base import Base, DB
from .cars import Cars


class Make(Base):
    __tablename__ = 'make'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, unique=True)
    make_car = relationship(Cars, back_populates="car_make")

    @staticmethod
    def get_all():
        pass

    @staticmethod
    def get_by_id(id: int):
        pass

    @staticmethod
    def remove():
        pass

    def __repr__(self):
        return str(self.__dict__)