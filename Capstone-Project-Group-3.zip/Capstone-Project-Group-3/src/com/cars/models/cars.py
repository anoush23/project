from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from .base import Base, DB
from .make import Make
from .model import Model
from .bodytype import BodyType


class Cars(Base):
    __tablename__ = 'cars'

    id = Column(Integer, primary_key=True, autoincrement=True)
    car_id = Column(Integer, nullable=False)
    price = Column(Integer)
    link_picture = Column(String)
    make = Column(Integer, ForeignKey("make.id"))
    car_make = relationship(Make, back_populates="make_car")
    model = Column(Integer, ForeignKey("model.id"))
    car_model = relationship(Model, back_populates="model_car")
    body_type = Column(Integer, ForeignKey("bodytype.id"))
    car_bodytype = relationship(BodyType, back_populates="bodytype_car")
    produced_year = Column(String)
    mileage = Column(String)
    engine_type = Column(String)
    engine_size = Column(String)
    transmission = Column(String)
    drive_type = Column(String)
    color = Column(String)
    steering_wheel = Column(String)
    cleared_customs = Column(String)

    @staticmethod
    def get_all():
        try:
            return DB.query(Cars).order_by(Cars.id.desc()).all()
        except:
            DB.rollback()

    @staticmethod
    def get_by_id(id: int):
        try:
            return DB.query(Cars).filter(Cars.car_id == id).first()
        except:
            DB.rollback()

    @staticmethod
    def remove():
        pass

    def __repr__(self):
        return str(self.__dict__)