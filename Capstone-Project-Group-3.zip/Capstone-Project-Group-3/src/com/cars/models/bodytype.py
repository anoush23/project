from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from .base import Base, DB
from .cars import Cars


class BodyType(Base):
    __tablename__ = 'bodytype'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, unique=True)
    bodytype_car = relationship(Cars, back_populates="car_bodytype")

    @staticmethod
    def get_all():
        pass

    @staticmethod
    def get_by_id(id: int):
        pass

    @staticmethod
    def remove():
        pass

    def __repr__(self):
        return str(self.__dict__)