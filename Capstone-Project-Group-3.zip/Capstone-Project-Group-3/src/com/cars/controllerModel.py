from .models.model import Model

class ModelController:
    def get_all(self):
        return Model.all()

    def get_by_id(self, id):
        return Model.get_by_id(id)