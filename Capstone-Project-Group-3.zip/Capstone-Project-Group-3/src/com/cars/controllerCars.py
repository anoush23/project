from .models.cars import Cars

class CarsController:
    def get_all(self):
        return Cars.get_all()

    def get_by_id(self, id):
        return Cars.get_by_id(id)