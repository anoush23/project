from flask import Flask, render_template
from datetime import datetime
from config import sys_conf, sec_conf, db_conf
from scripts.scrape import Soup
from scripts.insert_db import DBSession
from com.cars.routes import cars


app = Flask(__name__)


@app.context_processor
def get_date():
    return dict(now=datetime.utcnow())


@app.route('/')
def index():
    return render_template('layouts/index.html')


@app.route('/about')
def get_about():
    return render_template('layouts/about.html')


@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html')

app.register_blueprint(cars)


if __name__ == '__main__':
    url = "https://www.list.am/en/category/23"
    user_agent = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                      " AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.128 Safari/537.36"
    }
    list_data = Soup(url, user_agent)
    current_session = DBSession(db_conf['path'])
    current_session.insert_database(list_data.scraper())

    app.run(sys_conf['host'], int(sys_conf['port']),  sys_conf['debug'])