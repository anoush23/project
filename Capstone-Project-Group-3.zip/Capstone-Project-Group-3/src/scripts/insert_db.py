from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .db import Cars, Make, Model, BodyType


class DBSession:
    def __init__(self, db_name: str):

        self.__engine = create_engine(db_name)
        self.__session_maker = sessionmaker(bind=self.__engine)()
        self.__session = self.__session_maker

    def __insert_body_type(self, info_list: list):
        list_body_type = []
        obj_list = []
        for row in info_list:
            list_body_type.append(row["Body Type"])

        for make in set(list_body_type):
            new_obj = BodyType(name=make)
            obj_list.append(new_obj)

        self.__session.bulk_save_objects(obj_list)

    def __insert_make(self, info_list: list):
        list_make = []
        obj_list = []
        for row in info_list:
            list_make.append(row["Make"])

        for make in set(list_make):
            new_obj = Make(name=make)
            obj_list.append(new_obj)

        self.__session.bulk_save_objects(obj_list)

    def __insert_model(self, info_list: list):
        list_model = []
        obj_list = []
        for row in info_list:
            list_model.append(row["Model"])

        for model in set(list_model):
            new_obj = Model(name=model)
            obj_list.append(new_obj)

        self.__session.bulk_save_objects(obj_list)

    def __insert_cars(self, info_list: list):
        list_tale_cars = []
        for row in info_list:
            table_car = Cars(
                price=row.get("price"),
                link_picture=row.get("link_picture"),
                make=(self.__session.query(Make).filter_by(name=row["Make"]).one()).id,
                model=(
                    self.__session.query(Model).filter_by(name=row["Model"]).one()
                ).id,
                produced_year=row.get("Year"),
                body_type=(
                    self.__session.query(BodyType)
                    .filter_by(name=row["Body Type"])
                    .one()
                ).id,
                mileage=row.get("Mileage"),
                engine_type=row.get("Engine Type"),
                engine_size=row.get("Engine Size"),
                transmission=row.get("Transmission"),
                drive_type=row.get("Drive Type"),
                color=row.get("Color"),
                steering_wheel=row.get("Steering Wheel"),
                cleared_customs=row.get("Cleared Customs"),
            )
            list_tale_cars.append(table_car)
        self.__session.bulk_save_objects(list_tale_cars)

    def insert_database(self, info_list: list):

        self.__insert_make(info_list)
        self.__insert_model(info_list)
        self.__insert_body_type(info_list)
        self.__insert_cars(info_list)

        self.__session.commit()
