# import re
import requests
from bs4 import BeautifulSoup
from collections import defaultdict
from .operations_db import create_db, delete_db


class Soup:
    def __init__(self, link: str, header):
        self.link = link
        self.header = header
        self.__response = requests.get(link, headers=header)
        self.__webpage = self.__response.content
        self.soup = BeautifulSoup(self.__webpage, "html.parser")

    def __scrape_links(self) -> list:
        delete_db()
        create_db()
        soup_instance = Soup(self.link, self.header)
        profile_link = []
        for line in soup_instance.soup.find_all("div", {"class": "gl"}):
            for link in line.find_all("a"):
                profile_link.append(f'https://www.list.am/{link["href"]}')
        return profile_link

    def __scraper_carid(self, current_dict: dict, link) -> dict:
        try:
            carid = link.split('/')[::-1][0]
            current_dict["car_id"] = carid
        except AttributeError:
            current_dict["car_id"] = 0
        return current_dict

    def __scraper_price(self, current_soup, current_dict: dict) -> dict:
        try:
            text = current_soup.soup.find("span", {"class": "price"}).get_text()
            chars = "$֏,"
            for char in chars:
                text = text.replace(char, '')
            current_dict["price"] = text
            # current_dict["price"] = int(
            #     (re.findall(r"\b\d+[,]+\b\d+\b", text)[0].replace(",", ""))
            # )
        except AttributeError:
            current_dict["price"] = 0
        return current_dict

    def __scraper_link_picture(self, current_soup, current_dict: dict) -> dict:
        current_dict["link_picture"] = current_soup.soup.find("img").attrs["src"]
        return current_dict

    def __scraper_data(
        self, current_soup, current_dict: dict, list_dicts: list
    ) -> list:
        attr = current_soup.soup.find("div", attrs={"id": "attr"})
        details = attr.find_all("div", {"class": "c"})

        for detail in details:
            key = detail.find("div", {"class": "t"}).get_text()
            value = detail.find("div", {"class": "i"}).get_text()
            current_dict[key] = value
        list_dicts.append(dict(current_dict))

        return list_dicts

    def scraper(self) -> list:
        links = self.__scrape_links()
        data = []

        for link in links:
            current_soup = Soup(link, self.header)
            current_dict = defaultdict()

            self.__scraper_carid(current_dict, link)
            self.__scraper_price(current_soup, current_dict)
            try:
                self.__scraper_link_picture(current_soup, current_dict)
                self.__scraper_data(current_soup, current_dict, data)
            except AttributeError:
                continue

        return data
