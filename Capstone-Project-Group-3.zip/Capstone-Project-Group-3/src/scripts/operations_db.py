import os
from .db import Base
from sqlalchemy import create_engine
# from config import db_conf
# db_conf['path']


def create_db():
    engine = create_engine(f"sqlite:///data.db", echo=True)
    metadata = Base.metadata
    metadata.create_all(engine)
    print("db is created")


def delete_db():
    if os.path.isfile("data.db"):
        os.remove("data.db")
        print("db is deleted")
