from sqlalchemy import String, Column, Integer, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()


class BodyType(Base):
    __tablename__ = "body_type"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, unique=True)
    bodytype_car = relationship("Cars", back_populates="car_bodytype")


class Make(Base):
    __tablename__ = "make"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String) #unique=True
    make_car = relationship("Cars", back_populates="car_make")

    def __repr__(self):
        return str(self.__dict__)


class Model(Base):
    __tablename__ = "model"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String )#unique=True
    model_car = relationship("Cars", back_populates="car_model")

    def __str__(self):
        return str(self.__dict__)


class Cars(Base):
    __tablename__ = "cars"
    id = Column(Integer, primary_key=True, autoincrement=True)
    car_id = Column(Integer)
    price = Column(Integer)
    link_picture = Column(String)
    make = Column(Integer, ForeignKey("make.id"))
    model = Column(Integer, ForeignKey("model.id"))
    produced_year = Column(String)
    body_type = Column(Integer, ForeignKey("body_type.id"))
    mileage = Column(String)
    engine_type = Column(String)
    engine_size = Column(String)
    transmission = Column(String)
    drive_type = Column(String)
    color = Column(String)
    steering_wheel = Column(String)
    cleared_customs = Column(String)
    car_make = relationship("Make", back_populates="make_car")
    car_model = relationship("Model", back_populates="model_car")
    car_bodytype = relationship("BodyType", back_populates="bodytype_car")

    def __repr__(self):
        return str(self.__dict__)
