CREATE TABLE IF NOT EXISTS make(
	id integer PRIMARY KEY AUTOINCREMENT,
	name text UNIQUE
);
CREATE TABLE IF NOT EXISTS model(
	id integer PRIMARY KEY AUTOINCREMENT,
	name text UNIQUE
);
CREATE TABLE IF NOT EXISTS bodytype(
	id integer PRIMARY KEY AUTOINCREMENT,
	name text UNIQUE
);
CREATE TABLE IF NOT EXISTS cars(
	id integer PRIMARY KEY AUTOINCREMENT,
	car_id integer,
	price integer,
	link_picture text,
	make integer,
	model integer,
	body_type integer,
	produced_year text,
	mileage text,
	engine_type text,
	engine_size text,
	transmission text,
	drive_type text,
	color text,
	steering_wheel text,
	cleared_customs text,
	FOREIGN KEY (make) REFERENCES make(id),
	FOREIGN KEY (model) REFERENCES model(id),
	FOREIGN KEY (body_type) REFERENCES bodytype(id)
);