(function($) {
	
    console.log( "ready" );

})(jQuery)